import pandas as pd
import numpy as np
import seaborn as sns
from plotly import graph_objs as go
import plotly.express as px
from matplotlib import pyplot as plt
import streamlit as st
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score

df=pd.read_csv('Bank_dataset.csv')
df.drop("Unnamed: 0",axis=1, inplace = True)
df=df[df["aon"].str.contains("UA")==False]
df=df[df["daily_decr30"].str.contains("UA")==False]
df=df[df["daily_decr90"].str.contains("UA")==False]
df=df[df["rental30"].str.contains("UA")==False]
df=df[df["rental90"].str.contains("UA")==False]
df[['aon','daily_decr30', 'daily_decr90','rental30',
       'rental90']]=df[[ 'aon', 'daily_decr30', 'daily_decr90','rental30',
       'rental90']].apply(pd.to_numeric)
st.set_page_config(page_title="Bank Fraud detection app",
                 page_icon=':bar_chart:',
                   layout="wide")


nav=st.sidebar.radio("Navigator",["Home","Prediction","Contact us"])


if nav == "Home":
        st.title("Bank Fraud detection")
        st.image("bank1.jpg")
        if st.checkbox("Show Sample Data"):
                st.table(df.head())
        st.header('Visualisation and Analysis')
        plt.figure(figsize = (10,5))
        st.subheader("Correlation")
        corr=df.corr()
        fig, ax = plt.subplots()
        sns.heatmap(df.corr(), ax=ax)
        st.write(fig)
        graph = st.selectbox("Monthly Basis Data ",
                             ["over last 30 days","over last 90 days"])
        if graph=="over last 30 days":
              
            lst = [df]
            for column in lst:
                column.loc[column["rental30"] <= 0,  'balance_group'] = 'no balance'
                column.loc[(column["rental30"] > 0) & (column["rental30"] <= 19766), 'balance_group'] = 'low balance'
                column.loc[(column["rental30"] > 19766) & (column["rental30"] <= 118572), 'balance_group'] = 'average balance'
                column.loc[(column["rental30"] > 118572), 'balance_group'] = 'high balance'
            count_balance_response_pct = pd.crosstab(df['label'],df['balance_group']).apply(lambda x: x/x.sum() * 100)
            count_balance_response_pct = count_balance_response_pct.transpose()
            bal = pd.DataFrame(df['balance_group'].value_counts())
            bal['paying back the loan']= count_balance_response_pct[1]
            fig_p=px.bar(bal['paying back the loan'],
            title='Fig1.: Balance Category(rental30) vs loan pay back rate with in 5 days',)
            st.plotly_chart(fig_p)
            st.header('Insights')
            st.write("""The above bar plot infers us how customers with different main balance levels
are paying back the loan with in five days. The high balance level people are with 100% rate i.e they are paying loan within 5 days. Coming to the average and
 low balance people it is observed that around 10%-12% of people are not paying the loan within 5 days.
Coming to low balance level people, it is observed that around 30% of people are not paying back the loan
with in stipulated 5 days of time. The 30% of people with no balance or negative balance people are creating a
major loss to the company without paying back the loan within five days of time.""")


            lst = [df]
            for column in lst:
                    column.loc[column["fr_ma_rech30"] <=0,  'frequency_group'] = 'no frequency'
                    column.loc[(column['fr_ma_rech30'] > 0) & (column['fr_ma_rech30'] <=1 ), 'frequency_group'] = 'low frequency'
                    column.loc[(column['fr_ma_rech30'] >1) & (column['fr_ma_rech30'] <=2), 'frequency_group'] = 'medium frequency'
                    column.loc[(column['fr_ma_rech30'] >2), 'frequency_group'] = 'high frequency'

            count_fre_response_pct = pd.crosstab(df['label'],df['frequency_group']).apply(lambda x: x/x.sum() * 100)
            count_fre_response_pct = count_fre_response_pct.transpose()
            fre = pd.DataFrame(df['frequency_group'].value_counts())
            fre[' frequency levels'] = count_fre_response_pct[1]
            fig_p=px.bar(fre[' frequency levels'],
            title='Fig2.: Frequency Category(fr_ma_rech30) vs loan pay back rate with in 5 days',)
            st.plotly_chart(fig_p)
            st.header('Insights')
            st.write("""The above bar plot infers us how customers with different frequency levels
(main account recharge) are paying back the loan within five days. The is no 100% rate in any of the
frequency levels to pay back the loan within 5 days. Coming to the average and low & medium frequency
people it is observed that around 5%-6% of people are not paying the loan within 5 days.Coming to
low frequency level people, it is observed that around 25% of people are not paying back the loan
with in stipulated 5 days of time. The 25% people who are not getting their main account recharge
for 30 days creating a major loss to the company without paying back the loan within five days of time.""")


            lst = [df]
            for column in lst:
                    column.loc[column["cnt_loans30"] <=0,  'loan_frequency_group'] = 'no loans'
                    column.loc[(column['cnt_loans30'] > 0) & (column['cnt_loans30'] <=1 ), 'loan_frequency_group'] = 'low num of loans'
                    column.loc[(column['cnt_loans30'] >1) & (column['cnt_loans30'] <=4), 'loan_frequency_group'] = 'medium num of loans'
                    column.loc[(column['cnt_loans30'] >4), 'loan_frequency_group'] = 'high num of loans'
            count_loan_response_pct = pd.crosstab(df['label'],df['loan_frequency_group']).apply(lambda x: x/x.sum() * 100)
            count_loan_response_pct = count_loan_response_pct.transpose()
            fre = pd.DataFrame(df['loan_frequency_group'].value_counts())
            fre['number of loans'] = count_loan_response_pct[1]
            fig_p=px.bar(fre['number of loans'],orientation='h',
            title='Fig3.: number of loans(cnt_loans30) vs loan pay back rate with in 5 days',)
            st.plotly_chart(fig_p)
            st.header('Insights')
            st.write("""The above bar plot infers us how customers with different loans levels taken
are paying back the loan within five days. In the data set people not taken loans are labelled as
‘1’. So we should not consider the people with no loans labelled in the above graph.Considering
the remaining levels, there is no 100% rate in any of the loan levels to pay back the loan within
5 days. Coming to the high number of loan level people it is observed that around 2% of people
are not paying the loan within 5 days. Only 24% of the people from low number of loans category are
not paying the loan within 5 days. This is followed by the people with medium number of loans
having defaulters of 7% approximately""")


            lst = [df]
            for column in lst:
                    column.loc[column["amnt_loans30"] <=0,  'loanamnt_frequency_group'] = 'no loans'
                    column.loc[(column['amnt_loans30'] > 0) & (column['amnt_loans30'] <=6 ), 'loanamnt_frequency_group'] = 'low amnt of loans'
                    column.loc[(column['amnt_loans30'] >6) & (column['amnt_loans30'] <=24), 'loanamnt_frequency_group'] = 'medium amnt of loans'
                    column.loc[(column['amnt_loans30'] >24), 'loanamnt_frequency_group'] = 'high amnt of loans'
            count_loanamnt_response_pct = pd.crosstab(df['label'],df['loanamnt_frequency_group']).apply(lambda x: x/x.sum() * 100)
            count_loanamnt_response_pct = count_loanamnt_response_pct.transpose()
            fre1 = pd.DataFrame(df['loanamnt_frequency_group'].value_counts())
            fre1['Total amount of loans'] = count_loanamnt_response_pct[1]
            fig_p=px.bar(fre1['Total amount of loans'],
            title='Fig4.: total amount of loans(amnt_loans30) vs loan pay back rate with in 5 days',)
            st.plotly_chart(fig_p)
            st.header('Insights')
            st.write("""The above bar plot infers us how customers with different loans levels taken
are paying back the loan within five days. In the data set people not taken loans are labelled as
‘1’. So we should not consider the people with no loans labelled in the above graph.Considering
the remaining levels, there is no 100% rate in any of the loan levels to pay back the loan within
5 days. Coming to the low amount level people it is observed that around 25% of people are not
paying the loan within 5 days. Only 2% of the people taken high amount of loans are not paying the
loan within 5 days. This is followed by the people with medium number of loans having defaulters
of 7% approximately.""")


        if graph=="over last 90 days":
                    lst = [df]
                    for column in lst:
                        column.loc[column["rental90"] <= 0,  'balance_group'] = 'no balance'
                        column.loc[(column["rental90"] > 0) & (column["rental90"] <= 19766), 'balance_group'] = 'low balance'
                        column.loc[(column["rental90"] > 19766) & (column["rental90"] <= 118572), 'balance_group'] = 'average balance'
                        column.loc[(column["rental90"] > 118572), 'balance_group'] = 'high balance'
                    count_balance_response_pct = pd.crosstab(df['label'],df['balance_group']).apply(lambda x: x/x.sum() * 100)
                    count_balance_response_pct = count_balance_response_pct.transpose()
                    bal = pd.DataFrame(df['balance_group'].value_counts())
                    bal['paying back the loan']= count_balance_response_pct[1]
                    fig_p=px.bar(bal['paying back the loan'],
                    title='Fig1.: Balance Category(rental90) vs loan pay back rate with in 5 days',)
                    st.plotly_chart(fig_p)
                    st.header('Insights')
                    st.write("""The above bar plot infers us how customers with different main balance levels
are paying back the loan with in five days. The high balance level people are with 100% rate i.e they are paying loan within 5 days. Coming to the average and
 low balance people it is observed that around 6%-12% of people are not paying the loan within 5 days.
Coming to low balance level people, it is observed that around 32% of people are not paying back the loan
with in stipulated 5 days of time. The 32% of people with no balance or negative balance people are creating a
major loss to the company without paying back the loan within five days of time.""")


                    lst = [df]
                    for column in lst:
                            column.loc[column["fr_ma_rech90"] <=0,  'frequency_group'] = 'no frequency'
                            column.loc[(column['fr_ma_rech90'] > 0) & (column['fr_ma_rech90'] <=1 ), 'frequency_group'] = 'low frequency'
                            column.loc[(column['fr_ma_rech90'] >1) & (column['fr_ma_rech90'] <=2), 'frequency_group'] = 'medium frequency'
                            column.loc[(column['fr_ma_rech90'] >2), 'frequency_group'] = 'high frequency'

                    count_fre_response_pct = pd.crosstab(df['label'],df['frequency_group']).apply(lambda x: x/x.sum() * 100)
                    count_fre_response_pct = count_fre_response_pct.transpose()
                    fre = pd.DataFrame(df['frequency_group'].value_counts())
                    fre[' frequency levels'] = count_fre_response_pct[1]
                    fig_p=px.bar(fre[' frequency levels'],
                    title='Fig2.: Frequency Category(fr_ma_rech90) vs loan pay back rate with in 5 days',)
                    st.plotly_chart(fig_p)
                    st.header('Insights')
                    st.write("""The above bar plot infers us how customers with different frequency levels
(main account recharge) are paying back the loan within five days. The is no 100% rate in any of the
frequency levels to pay back the loan within 5 days. Coming to the average and low & medium frequency
people it is observed that around 5%-7% of people are not paying the loan within 5 days.Coming to
low frequency level people, it is observed that around 25% of people are not paying back the loan
with in stipulated 5 days of time. The 27% people who are not getting their main account recharge
for 90 days creating a major loss to the company without paying back the loan within five days of time.""")



                    lst = [df]
                    for column in lst:
                            column.loc[column["cnt_loans90"] <=0,  'loan_frequency_group'] = 'no loans'
                            column.loc[(column['cnt_loans90'] > 0) & (column['cnt_loans90'] <=1 ), 'loan_frequency_group'] = 'low num of loans'
                            column.loc[(column['cnt_loans90'] >1) & (column['cnt_loans90'] <=4), 'loan_frequency_group'] = 'medium num of loans'
                            column.loc[(column['cnt_loans90'] >4), 'loan_frequency_group'] = 'high num of loans'
                    count_loan_response_pct = pd.crosstab(df['label'],df['loan_frequency_group']).apply(lambda x: x/x.sum() * 100)
                    count_loan_response_pct = count_loan_response_pct.transpose()
                    fre = pd.DataFrame(df['loan_frequency_group'].value_counts())
                    fre['number of loans'] = count_loan_response_pct[1]
                    fig_p=px.bar(fre['number of loans'],orientation='h',
                    title='Fig3.: number of loans(cnt_loans90) vs loan pay back rate with in 5 days',)
                    st.plotly_chart(fig_p)
                    st.header('Insights')
                    st.write("""The above bar plot infers us how customers with different loans levels taken
are paying back the loan within five days. In the data set people not taken loans are labelled as
‘1’. So we should not consider the people with no loans labelled in the above graph.Considering
the remaining levels, there is no 100% rate in any of the loan levels to pay back the loan within
5 days. Coming to the high number of loan level people it is observed that around 2% of people
are not paying the loan within 5 days. Only 26% of the people from low number of loans category are
not paying the loan within 5 days. This is followed by the people with medium number of loans
having defaulters of 7% approximately""")


                    lst = [df]
                    for column in lst:
                            column.loc[column["amnt_loans90"] <=0,  'loanamnt_frequency_group'] = 'no loans'
                            column.loc[(column['amnt_loans90'] > 0) & (column['amnt_loans90'] <=6 ), 'loanamnt_frequency_group'] = 'low amnt of loans'
                            column.loc[(column['amnt_loans90'] >6) & (column['amnt_loans90'] <=24), 'loanamnt_frequency_group'] = 'medium amnt of loans'
                            column.loc[(column['amnt_loans90'] >24), 'loanamnt_frequency_group'] = 'high amnt of loans'
                    count_loanamnt_response_pct = pd.crosstab(df['label'],df['loanamnt_frequency_group']).apply(lambda x: x/x.sum() * 100)
                    count_loanamnt_response_pct = count_loanamnt_response_pct.transpose()
                    fre1 = pd.DataFrame(df['loanamnt_frequency_group'].value_counts())
                    fre1['Total amount of loans'] = count_loanamnt_response_pct[1]
                    fig_p=px.bar(fre1['Total amount of loans'],
                    title='Fig4.: total amount of loans(amnt_loans90) vs loan pay back rate with in 5 days',)
                    st.plotly_chart(fig_p)
                    st.header('Insights')
                    st.write("""The above bar plot infers us how customers with different loans levels taken
are paying back the loan within five days. In the data set people not taken loans are labelled as
‘1’. So we should not consider the people with no loans labelled in the above graph.Considering
the remaining levels, there is no 100% rate in any of the loan levels to pay back the loan within
5 days. Coming to the low amount level people it is observed that around 27% of people are not
paying the loan within 5 days. Only 2% of the people taken high amount of loans are not paying the
loan within 5 days. This is followed by the people with medium number of loans having defaulters
of 7% approximately.""")
if nav=="Prediction":
        x=df.drop(['label','msisdn','aon','pcircle','pdate','daily_decr30',
'daily_decr90','last_rech_date_ma','last_rech_date_da','last_rech_amt_ma','sumamnt_ma_rech30',
'medianamnt_ma_rech30','medianmarechprebal30','sumamnt_ma_rech90','medianamnt_ma_rech90',
'medianmarechprebal90','medianamnt_loans90','maxamnt_loans90','medianamnt_loans30','maxamnt_loans30','cnt_da_rech90','fr_da_rech90'
,'cnt_da_rech30','fr_da_rech30','payback90','fr_ma_rech30','payback30','fr_ma_rech90'],axis=1)
        y=df['label']
        from sklearn.model_selection import train_test_split
        x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.33)
        st.title("Bank Fraud detection")
        st.write("""input parameters""")

        def user_input_feature():
                rental30=st.slider('rental30',-23737.140000,198926.110000)
                rental90=st.slider('rental90',-24720.580000,200148.110000)
                cnt_ma_rech30=st.slider('cnt_ma_rech30', 0.000000,203.000000)
                cnt_ma_rech90=st.slider('cnt_ma_rech90',0.000000,336.000000)
                cnt_loans30=st.slider('cnt_loans30',0.000000,50.000000)
                cnt_loans90=st.slider('cnt_loans90',0.000000,4997.517944)
                amnt_loans30=st.slider('amnt_loans30',0.000000,306.000000)
                amnt_loans90=st.slider('amnt_loans90',0.000000,438.000000)
                
                data={
                'rental30':rental30,
                'cnt_ma_rech30':cnt_ma_rech30,
                'cnt_loans30':cnt_loans30,
                'amnt_loans30':amnt_loans30,
                'cnt_ma_rech90':cnt_ma_rech90,
                'cnt_loans90':cnt_loans90,
                'amnt_loans90':amnt_loans90,
                'rental90':rental90}
                features=pd.DataFrame(data,index=[0])
                return features
        input_df=user_input_feature()

        st.header('Specified input parameters')
        st.write(input_df)
        select_alg=st.selectbox("Choose Algorithm for Efficient Predict",['Random Forest Model','D Tree Model','KNeighborsClassifier'])
        
        if select_alg=='Random Forest Model':
                st.write('Random Forest Model')
                rf = RandomForestClassifier(n_estimators = 50,criterion = "entropy")
                rf.fit(x_train, y_train)
                y_pred=rf.predict(x_test)
                prediction=rf.predict(input_df)
        if select_alg=='D Tree Model':
                st.write('D Tree Model')
                D_tree = DecisionTreeClassifier(criterion="entropy")
                D_tree.fit(x_train, y_train)
                y_pred=D_tree.predict(x_test)
                prediction=D_tree.predict(input_df)
        if select_alg=='KNeighborsClassifier':
                acc = []
                for k in range(1, 50, 2):
                    model = KNeighborsClassifier(n_neighbors= k)
                    model.fit(x_train, y_train)
                    y_pred = model.predict(x_test)
                    acc.append(accuracy_score(y_test, y_pred))
                x=acc.index(max(acc))
                st.write('KNeighborsClassifier')
                knn = KNeighborsClassifier(n_neighbors=x, metric = "euclidean")
                knn.fit(x_train, y_train)
                y_pred=knn.predict(x_test)
                prediction=knn.predict(input_df)
        st.subheader('Prediction')
        l_model=np.array(df['label'])
        st.write(l_model[prediction])
        st.header('confusion matrix')
        st.write(confusion_matrix(y_test,y_pred))
        st.write('f1_score',f1_score(y_test,y_pred))
        
if nav=="Contact us":
        st.image('download.png')
        st.header("Contact Us")
        st.markdown("""
        **Name:** Ashish Yadav\n
        **mail id:** yadavashish804321@gmail.com\n
        **Contact:** +917720982056\n
        **Linkein:** https://www.linkedin.com/in/ashish-yadav-05baa6235/\n
        """)
        st.markdown("""
        **Name:** Surya Bharadwaj\n
        **mail id:** bsuryabharadwaj75@gmail.com\n
        **Contact:** +918496874611\n
        **Linkein:** https://www.linkedin.com/in/surya-bharadwaj-b-16a071236/\n
        """)
        









       
